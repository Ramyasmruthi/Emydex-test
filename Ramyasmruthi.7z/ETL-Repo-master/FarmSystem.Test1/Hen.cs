﻿using System;

namespace FarmSystem.Test1
{
    public class Hen :Animal
    {
        public override void Talk()
        {
            Console.WriteLine("Hen say CLUCKAAAAAWWWWK!");
        }

        public override  void Run()
        {
            Console.WriteLine("Hen is running");
        }

        public override void Enter()
        {
            Console.WriteLine("Hen has entered the farm");
        }
    }
}