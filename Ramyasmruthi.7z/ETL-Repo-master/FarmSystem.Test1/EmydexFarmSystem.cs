﻿using FarmSystem.Test2;
using System;
using System.Collections.Generic;

namespace FarmSystem.Test1
{
    public class EmydexFarmSystem
    {
        List<Animal> animals = new List<Animal>();
        //TEST 1
        public void Enter(Animal animal)
        {
            animals.Add(animal);
            animal.Enter();
        }

        //TEST 2
        public void MakeNoise()
        {
            foreach (Animal a in animals)
            {
                a.Talk();
            }
        }

        //TEST 3
        public void MilkAnimals()
        {
            foreach (Animal a in animals)
            {
                if (a is IMilkableAnimal)
                {
                    Console.WriteLine(a.GetType().Name + " was milked!");
                }
            }
        }

        //TEST 4
        public void ReleaseAllAnimals()
        {
            clearList(animals);
        }
        public void clearList(List<Animal> lstanimals)
        {
            List<Animal> newList = new List<Animal>();
            if (lstanimals.Count > 0)
            {
                newList = lstanimals.GetRange(1, lstanimals.Count - 1);
                Animal a = lstanimals[0];
                Console.WriteLine(a.GetType().Name + " has left the farm");
                lstanimals.RemoveAt(0);
                if (newList.Count > 0)
                {
                    clearList(newList);
                }
                else
                {
                    Console.WriteLine("Emydex Farm is now empty");
                }
            }
        }
    }
}